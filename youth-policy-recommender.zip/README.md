# 온통청년 개인화 정책 추천 (MVP)
React(Vite) + Tailwind로 만든 개인화 정책 추천 웹앱.

## 실행
```bash
npm i
npm run dev   # http://localhost:5173
```

## 실제 API (선택)
- 모의데이터 체크를 끄고 openApiVlak(API Key)를 입력하세요.
- CORS 우회 필요 시:
```bash
node server.js   # http://localhost:4000
```
그 후 프런트 코드에서 fetch URL을 프록시로 바꾸면 됩니다.

## 배포
Vercel에서 Vite 프로젝트로 배포하세요. (Build: `npm run build`, Output: `dist`)
