export async function fetchPolicies({ useMock = true, apiKey = "", startIndex = 1, display = 100, regionCode = "", fieldCode = "" } = {}) {
  if (useMock || !apiKey) {
    const data = await import("./mock.json");
    return data.default.youthPolicy;
  }
  // Youth Center Open API
  const base = "https://www.youthcenter.go.kr/opi/youthPlcyList.do";
  const params = new URLSearchParams({
    openApiVlak: apiKey,
    startIndex: String(startIndex),
    display: String(display),
  });
  if (regionCode) params.set("srchPolyBizRegd", regionCode);
  if (fieldCode) params.set("srchPolyBizSecd", fieldCode);
  // CORS 주의: 필요 시 server.js 프록시 사용
  const url = `${base}?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("API 요청 실패: " + res.status);
  const text = await res.text();
  try {
    return JSON.parse(text).youthPolicy || [];
  } catch (_) {
    const doc = new DOMParser().parseFromString(text, "application/xml");
    const items = Array.from(doc.querySelectorAll("youthPolicy > youthPolicyList"));
    return items.map((el) => ({
      bizId: el.querySelector("bizId")?.textContent ?? "",
      polyBizSjnm: el.querySelector("polyBizSjnm")?.textContent ?? "",
      cnsgNmor: el.querySelector("cnsgNmor")?.textContent ?? "",
      plcyTpNm: el.querySelector("plcyTpNm")?.textContent ?? "",
      rqutPrdCn: el.querySelector("rqutPrdCn")?.textContent ?? "",
      rqutUrla: el.querySelector("rqutUrla")?.textContent ?? "",
      sporCn: el.querySelector("sporCn")?.textContent ?? "",
      ageMin: 19,
      ageMax: 39,
      region: ["전국"]
    }));
  }
}
export function filterPolicies(policies, { age, region, field }) {
  return policies.filter((p) => {
    const ageOk = !age || ((p.ageMin ?? 0) <= age && age <= (p.ageMax ?? 200));
    const regionOk = !region || (p.region?.includes("전국") || p.region?.some(r => String(r).includes(region)));
    const fieldOk = !field || (p.plcyTpNm && p.plcyTpNm.includes(field));
    return ageOk && regionOk && fieldOk;
  });
}
