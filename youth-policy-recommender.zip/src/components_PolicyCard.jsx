export default function PolicyCard({ p }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm hover:shadow-md transition">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">{p.polyBizSjnm}</h3>
          <p className="text-sm text-gray-500">{p.cnsgNmor} · {p.plcyTpNm}</p>
        </div>
        <span className="text-xs rounded-full bg-gray-100 px-2 py-1 text-gray-600">{p.bizId}</span>
      </div>
      <p className="mt-2 text-gray-800">{p.sporCn}</p>
      <div className="mt-3 text-sm text-gray-600">신청기간: {p.rqutPrdCn || "수시"}</div>
      <div className="mt-4">
        <a href={p.rqutUrla} target="_blank" rel="noreferrer" className="inline-flex items-center rounded-xl border px-3 py-1.5 text-sm hover:bg-gray-50">신청하기 ↗</a>
      </div>
    </div>
  )
}
