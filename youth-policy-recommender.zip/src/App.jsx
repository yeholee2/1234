import { useEffect, useMemo, useState } from "react";
import "./styles/index.css";
import { fetchPolicies, filterPolicies } from "./lib_api";
import PolicyCard from "./components_PolicyCard";

const REGIONS = ["전국", "서울", "부산", "대구", "인천", "광주", "대전", "울산", "세종", "경기", "강원", "충북", "충남", "전북", "전남", "경북", "경남", "제주"];
const FIELDS = ["전체", "취업", "주거", "금융", "교육", "창업·기업", "건강", "문화·체육"];

export default function App() {
  const [age, setAge] = useState(25);
  const [region, setRegion] = useState("서울");
  const [field, setField] = useState("전체");
  const [apiKey, setApiKey] = useState("");
  const [useMock, setUseMock] = useState(true);
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");

  async function load() {
    setLoading(true);
    try {
      const data = await fetchPolicies({ useMock, apiKey });
      setPolicies(data);
    } catch (e) {
      console.error(e);
      alert("데이터를 불러오지 못했습니다. (가능한 원인: CORS / API Key 오류)");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [useMock]);

  const filtered = useMemo(() => {
    const base = filterPolicies(policies, { age, region, field: field === "전체" ? "" : field });
    if (!q) return base;
    return base.filter(p => (p.polyBizSjnm + " " + (p.sporCn ?? "") + " " + (p.plcyTpNm ?? "")).toLowerCase().includes(q.toLowerCase()));
  }, [policies, age, region, field, q]);

  return (
    <div className="mx-auto max-w-6xl p-4 md:p-8">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">온통청년 정책 추천</h1>
        <p className="text-gray-600 mt-1">나이·지역·관심분야를 바탕으로 나에게 맞는 정책만 모아 보여줍니다.</p>
      </header>

      <section className="rounded-2xl border bg-white p-4 md:p-6 shadow-sm">
        <div className="grid md:grid-cols-5 gap-3">
          <div className="md:col-span-1">
            <label className="block text-sm text-gray-600 mb-1">나이</label>
            <input type="number" min="15" max="45" value={age} onChange={e=>setAge(Number(e.target.value))}
              className="w-full rounded-xl border px-3 py-2"/>
          </div>
          <div className="md:col-span-1">
            <label className="block text-sm text-gray-600 mb-1">지역</label>
            <select value={region} onChange={e=>setRegion(e.target.value)} className="w-full rounded-xl border px-3 py-2">
              {REGIONS.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div className="md:col-span-1">
            <label className="block text-sm text-gray-600 mb-1">분야</label>
            <select value={field} onChange={e=>setField(e.target.value)} className="w-full rounded-xl border px-3 py-2">
              {FIELDS.map(f => <option key={f}>{f}</option>)}
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm text-gray-600 mb-1">검색</label>
            <input placeholder="정책명/내용 검색" value={q} onChange={e=>setQ(e.target.value)}
              className="w-full rounded-xl border px-3 py-2"/>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-3 text-sm">
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" checked={useMock} onChange={e=>setUseMock(e.target.checked)} />
            모의데이터 사용 (API 없이 테스트)
          </label>
          {!useMock && (
            <input placeholder="온통청년 openApiVlak (API Key)" value={apiKey} onChange={e=>setApiKey(e.target.value)}
              className="rounded-xl border px-3 py-1.5 text-sm w-80"/>
          )}
          <button onClick={load} className="ml-auto rounded-xl border px-3 py-1.5 hover:bg-gray-50">새로고침</button>
        </div>
      </section>

      <section className="mt-6">
        <div className="mb-2 text-sm text-gray-600">{loading ? "불러오는 중..." : `총 ${filtered.length}건`}</div>
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map(p => <PolicyCard key={p.bizId} p={p} />)}
        </div>
      </section>

      <footer className="mt-10 text-xs text-gray-500">
        * 실제 데이터는 온통청년(청년정책통합플랫폼) API를 사용합니다. 브라우저 CORS 이슈가 있으면 로컬 프록시를 사용하세요(README 참조).
      </footer>
    </div>
  );
}
