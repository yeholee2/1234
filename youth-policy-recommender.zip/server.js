import express from "express";
import fetch from "node-fetch";
const app = express();
const PORT = process.env.PORT || 4000;
app.get("/api/youth", async (req, res) => {
  try {
    const qs = req.query.query || "";
    const url = "https://www.youthcenter.go.kr/opi/youthPlcyList.do?" + qs;
    const r = await fetch(url);
    const text = await r.text();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.send(text);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});
app.listen(PORT, () => console.log("Proxy running on http://localhost:" + PORT));
